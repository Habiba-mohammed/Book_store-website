// export default class Book {
//     constructor(bookName, author, description, category, img) {
//         this.bookName = bookName;
//         this.author = author;
//         this.description = description;
//         this.category = category;
//         this.img = img;
//     }
// }
